#!/bin/sh
chmod +x .
hexo generate