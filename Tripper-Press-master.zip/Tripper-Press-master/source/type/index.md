---
title: Hexo-Theme-Type 文档
author: aiokr
permalink: 'type/'
abbrlink: '8998'
---

# 简介

Type 是一个简洁、专注于文字、照片展示的 Hexo 主题。本主题尚未正式发布，使用过程中可能遇到一些问题，请见谅。

[快速开始](getstart.html)

[主题设定](theme_settings.html)