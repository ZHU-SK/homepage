---
title: '瞬间 Press #1 过程总是有意义的'
author: aiokr
categories: 瞬间周报
abbrlink: a9cf
date: 2022-03-21 11:35:34
---

# 📖 Read

[又一频道停播！2022开年至今，已有8个频道、频率关停](https://mp.weixin.qq.com/s?__biz=MjM5Nzk3MTYxMg==&mid=2650435938&idx=1&sn=a32b8ebaaa7cf92b94c285fa5f9f0568&chksm=bedf029189a88b87ccd383d51448ca04dab11cff1d11a3477392fd4b9000fe65b96df75e3191#rd)

近几年来，短视频的普及，看电视的人已经越来越少了。电视台没有收视率就没有广告利润，频道的关停和整合也是在所难免。

[网络暴力黑产化，个人和社交平台如何守住防线？](https://mp.weixin.qq.com/s?__biz=MzA3MzQ1MzQzNA==&mid=2656984148&idx=1&sn=f741bc7e017783da8b25316880d646b3&chksm=84a42641b3d3af571ece3357bcf61d20ea3ed627625df530e87f54867c9cf4e030ad7de17df1#rd)

> 在每天都有海量数据上传的社交媒体中，某些个体会觉得“我的声音无足轻重”，在恶果酿成后也容易“放过”自己。
于是，暴力不断反复、叠加，形成强大的、难以估量的群体声音，而面对这些，被施暴的个体又是极其脆弱的。
> 

[大家为什么戒不掉“影视解说”？](https://mp.weixin.qq.com/s?__biz=MjM5Nzk3MTYxMg==&mid=2650435751&idx=1&sn=a3b1017ecf85c0e17ab444267ebeb867&chksm=bedf035489a88a423f5afc15fb586cfa65c8e46c2a3e9c0cb8de6e49eb46865d20a0a2ebabd9#rd)

> 自从“X分钟看完一部电影”随着短视频平台崛起大火，无论是“版权保护”还是所谓的“舆论影响”，都是从来没有算清的糊涂账。产业端周期性地抱怨影视解说“贩卖盗版资源”“侵犯创作者权益”，几乎成了内容创业圈里的保留节目。
> 

# 💡 Recommend

### imgggg

[imgggg | Capture and share anything as image](https://imgg.gg/)

imgg 是一个可以将任意 sms 内容转换成为图片的工具，不用担心在 APP 上截图会泄漏隐私。生成的图片的样式很像 Poet.so，不过 Poet.so 只能生成推特的分享图。

![](//imgur.lzmun.com/picgo/after2022/imggggg-export-2.png_itp)

### 金十数据

[金十数据 官方网站 - 一个交易工具！](https://www.jin10.com/)

一个一句话新闻网站

![](//imgur.lzmun.com/picgo/after2022/Untitled.png_itp)

---

# ✒️ 一些想法

这周一，2022考研的初试成绩出了，我考的新闻与传播专硕，拿到了348分，不高不低吧，算是没有愧对上个学期的努力。

本身我自认为我准备初试的期间并不是准备的太充分的，也不是太认真。拿到这个分数，有努力，但也有运气的成分在期间。

拿到成绩那天，我翻了翻flomo，发现我曾经在备考期间很多次给自己写下过“不管结果如何，过程总是有意义的”。我曾经很多次用这句话来激励我自己，即使已经觉得很艰难了，但也不要放弃。放弃了就意味着前功尽弃了，坚持即使没有结果，也是有意义的。

接下来，就应该好好准备复试了，虽然肯定看不完书了，但是书的大致内容或者目录还是可以过一遍的，英语口语也要练一下。

把中外新闻史都过一遍，实务的新书看一遍，看一下老师的论文。

加油吧💪

**无论结果如何，过程总是有意义的。**