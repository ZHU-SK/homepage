---
title: '瞬间 Press #3 reboot 重新开始'
author: aiokr
categories: 瞬间周报
abbrlink: 572d
date: 2022-03-22 09:41:32
---

# 📖 Read

[双链笔记软件推荐：Logseq 和它的五种用法 - 少数派](https://sspai.com/post/69503)

又开始尝试一个新的笔记软件，我真的已经陷入了“告别效率，回归工具”的陷阱哈哈哈。 说起来这次尝试Logseq，一个原因是看了一篇介绍[Workflowy](https://sspai.com/post/71739)的文章，想起来看到过Logseq的介绍，感觉和Workflowy有异曲同工之妙，而且还有本地化的优势，就索性下载来试试看。

[DaVinci Resolve 17 – Fusion | Blackmagic Design](http://www.blackmagicdesign.com/products/davinciresolve/fusion)

最近在学习Fusion制作特效，但是大部分教程都是英文的。我先尝试把官方的英文教程翻译一下。

[不搞投资搞设计，帝都金融狗LOFT装修全回顾！ - 少数派](https://sspai.com/post/71167)

房屋装修是我一直百看不厌的话题。最近南宁推出了「[商业办公楼实际用于居住，可按民用水电气价格交费](https://mp.weixin.qq.com/s/sicMp2LraNpTIwq9MawdpA)」的政策，我觉得LOFT又行了。

# 💡Recommend

[DaVinci Resolve 17 – Fusion | Blackmagic Design](http://www.blackmagicdesign.com/products/davinciresolve/fusion)

当然还是推荐 BMD 的 DaVinci Resolve，不仅可以剪辑视频，还可以处理音频、制作特效。

最重要的是支持M1，而且普通版免费，Studio版买断，和AE比起来简直是眉清目秀。

# ✒️ Essay

并不是所有的努力都一定会有结果，失败和平庸或许才是前进路上的常态。

前两天，2022年的考研国家线出来了，非常起飞，新闻与传播的国家线比去年上涨了12分。

收拾收拾找工作，准备重新开始吧。

（好像这一期咕咕得有点久了）