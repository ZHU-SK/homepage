---
title: 怀念青协的日子 经管青协十五周年宣传片
tags:
  - 视频
  - 摄影
categories: 视频
cover: 'https://imgur.lzmun.com/picgo/20190623215638.jpg_itp'
abbrlink: 30f6
date: 2019-06-24 18:30:00
---

{% bili %}
  <iframe src="//player.bilibili.com/player.html?aid=56764936&cid=56764936" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true"> </iframe>
{% endbili %}