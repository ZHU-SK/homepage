---
title: 庚子鼠年，你好
tags:
categories: 随笔
cover: 'https://imgur.lzmun.com/picgo/20200125133656.jpg'
style: smart
abbrlink: '9129'
date: 2020-01-25 13:28:50
---

永远相信美好的事情即将发生。

不知什么时候，我常常将这句话作为自己的座右铭。我不觉得他是我的所谓人生信条，只是为了提醒我，相信现在糟糕的一切都会变好的，一切都会变得越来越好的。

新年，快乐。

