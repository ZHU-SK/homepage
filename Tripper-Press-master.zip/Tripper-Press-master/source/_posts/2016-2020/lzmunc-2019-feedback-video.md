---
title: 2019 柳州市渊文模拟联合国大会 快剪视频
tags:
  - 模联
  - 视频
  - 摄影
categories:
  - 视频
cover: 'https://imgur.lzmun.com/picgo/20190611000730.jpg_itp'
abbrlink: 34ea
date: 2019-06-11 00:06:15
---

{% bili %}
 <iframe src="//player.bilibili.com/player.html?aid=55111783&cid=96535132&page=2" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true"></iframe>
{% endbili %}