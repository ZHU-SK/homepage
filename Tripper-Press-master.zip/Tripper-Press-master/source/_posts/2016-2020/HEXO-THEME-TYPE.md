---
title: 宣布 TYPE
cover: 'https://imgur.lzmun.com/picgo/20200128145845.jpg'
tags: hexo-theme-type
style: smart
categories: 项目
abbrlink: '1798'
date: 2020-01-28 14:59:20
---
在使用 Daily 主题一段时间后，终于把主题改造成了自己想要的亚子，趁着 2020 年春节假期哪也去不了的这段时间，下定决心把主题一些地方完善，发布出来。

主题的名称定为 TYPE，type 有打字的意思，希望 type 主题能帮助作者和读者更好地关注内容。

![主海报](https://imgur.lzmun.com/picgo/20200128145845.jpg)

TYPE 采用了 Material Design 风格，目前采用单栏设计（不排除以后加入双栏设计的可能）。hexo 中已经有了很多优秀的采用 Material Design 风格的主题，也给我在开发 TYPE 的过程中提供了很多参考。

目前，TYPE 有以下特性。

- 完善的系统级夜间模式的支持
- 多种文章入口样式
- 对打印机的优化
- 多种评论系统（包括 DisqusJS）的支持

最后，TYPE 以 MIT 协议发布在 [Github](https://github.com/aiokr/hexo-theme-type)，欢迎各位大佬前来参观和贡献。
