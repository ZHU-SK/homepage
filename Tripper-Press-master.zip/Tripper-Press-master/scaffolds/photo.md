---
title: {{ title }}
date: {{ date }}
author: aiokr
style: photos
permalink: 
gallery:
 - title: 
   src: 
---