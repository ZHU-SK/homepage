<img src="https://imgur.lzmun.com/picgo/20200124123627.jpg" alt="logo" width="72" height="72" align="right" />

# Tripper.Press 瞬间 Press

> 拿起相机，认真思考。
> Take Photo, Think Seriously

## 关于我

aiokr｜摄影｜航拍｜剪辑｜永远是学生

## 许可证信息

本仓库采用双重许可证授权模式。

本仓库 [/themes/hexo-theme-type/](https://github.com/aiokr/iTypen-Hexo/tree/master/source) 文件夹下的内容，以 [MIT](https://choosealicense.com/licenses/mit/) 协议分发。

本仓库其他文件夹下的内容，作者**保留所有权利，禁止分享、禁止演绎**。
