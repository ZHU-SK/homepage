hexo clean
hexo generate